def num_transformer(node, resources):
    return str(node.n)
