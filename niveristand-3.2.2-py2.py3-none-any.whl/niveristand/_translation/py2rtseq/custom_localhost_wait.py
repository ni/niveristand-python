def custom_localhost_wait(node, resources):
    return ""
